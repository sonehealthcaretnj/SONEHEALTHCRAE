# 🌐 Deployment Guide - S ONE Healthcare Website

Complete instructions for deploying your website on various platforms.

---

## Table of Contents
1. [Netlify (Recommended)](#netlify-recommended)
2. [Vercel](#vercel)
3. [GitHub Pages](#github-pages)
4. [Traditional Hosting](#traditional-hosting)
5. [Docker](#docker)
6. [Domain Setup](#domain-setup)
7. [SSL Certificate](#ssl-certificate)

---

## Netlify (Recommended)

### Why Netlify?
- ✓ Free tier generous
- ✓ Automatic HTTPS
- ✓ Global CDN
- ✓ Continuous deployment
- ✓ Easy form handling

### Step 1: Prepare Your Code

```bash
# Make sure you have these files:
- index.html
- css/styles.css
- js/main.js
- README.md
```

### Step 2: Create GitHub Repository

```bash
# Initialize git
git init

# Add files
git add .

# Commit
git commit -m "Initial commit - S ONE Healthcare website"

# Create repo on github.com
# Then push:
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/s-one-healthcare.git
git push -u origin main
```

### Step 3: Deploy on Netlify

1. Go to **netlify.com**
2. Click "New site from Git"
3. Connect your GitHub account
4. Select your repository
5. Configure build settings:
   - Build command: (leave empty for static site)
   - Publish directory: (leave empty, use root)
6. Click "Deploy site"

### Step 4: Custom Domain

1. Go to Site settings → Domain management
2. Click "Add domain"
3. Enter your domain (e.g., sonehealthcare.com)
4. Update DNS at your domain registrar:
   ```
   CNAME: your-site.netlify.app
   ```

### Form Handling with Netlify

Add to your form:
```html
<form name="contact" method="POST" netlify>
    <input type="text" name="name" placeholder="Your Name" required>
    <input type="email" name="email" placeholder="Your Email" required>
    <textarea name="message" placeholder="Your Message" required></textarea>
    <button type="submit">Send Message</button>
</form>
```

---

## Vercel

### Step 1: Prepare Project

```bash
# Create vercel.json in root:
{
  "buildCommand": "echo 'No build needed'",
  "outputDirectory": "."
}
```

### Step 2: Push to GitHub

(Same as Netlify setup above)

### Step 3: Deploy on Vercel

1. Go to **vercel.com**
2. Click "New Project"
3. Import your GitHub repository
4. Configure project:
   - Framework: Other
   - Root Directory: ./
5. Click "Deploy"

### Step 4: Custom Domain

1. Go to Project Settings → Domains
2. Add domain
3. Update DNS records shown

---

## GitHub Pages

### Step 1: GitHub Setup

```bash
# Create gh-pages branch
git checkout -b gh-pages

# Push to GitHub
git push origin gh-pages
```

### Step 2: Enable GitHub Pages

1. Go to your repository settings
2. Scroll to "GitHub Pages"
3. Select source: "gh-pages branch"
4. Click "Save"

### Step 3: Add Custom Domain

1. In GitHub Pages settings
2. Add custom domain
3. Update DNS CNAME record

**Note:** GitHub Pages is free but slower than Netlify/Vercel

---

## Traditional Hosting (cPanel)

### Step 1: Choose Hosting

Popular options:
- Bluehost ($2.95/month)
- HostGator ($2.75/month)
- GoDaddy ($6/month)
- SiteGround ($2.99/month)

### Step 2: FTP Upload

1. Get FTP credentials from hosting provider
2. Download FileZilla (free FTP client)
3. Connect:
   - Host: ftp.yourdomain.com
   - Username: your_cpanel_username
   - Password: your_password
   - Port: 21

4. Upload files to public_html folder:
```
public_html/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── main.js
└── README.md
```

### Step 3: Setup Domain

1. Point domain to hosting nameservers
2. Wait 24-48 hours for DNS propagation
3. Verify site loads

### Step 4: SSL Certificate

In cPanel:
1. Go to "AutoSSL"
2. Click "Check HTTPS Configuration"
3. Install certificate

---

## Docker Deployment

### Step 1: Create Dockerfile

```dockerfile
# Use lightweight web server image
FROM node:16-alpine

WORKDIR /app

# Copy website files
COPY . .

# Install simple HTTP server
RUN npm install -g http-server

# Expose port
EXPOSE 8000

# Start server
CMD ["http-server", "-p", "8000"]
```

### Step 2: Create .dockerignore

```
node_modules
.git
.gitignore
README.md
.env
```

### Step 3: Build & Run

```bash
# Build image
docker build -t s-one-healthcare .

# Run container
docker run -p 8000:8000 s-one-healthcare

# Access at http://localhost:8000
```

### Step 4: Deploy to Docker Hub

```bash
# Login
docker login

# Tag image
docker tag s-one-healthcare YOUR_USERNAME/s-one-healthcare:latest

# Push
docker push YOUR_USERNAME/s-one-healthcare:latest
```

### Step 5: Deploy to Cloud

**AWS:**
```bash
# Use AWS ECR and ECS
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com
```

**Google Cloud:**
```bash
# Use Google Container Registry
gcloud auth configure-docker
docker tag s-one-healthcare gcr.io/PROJECT_ID/s-one-healthcare
docker push gcr.io/PROJECT_ID/s-one-healthcare
```

---

## Domain Setup

### Step 1: Register Domain

Popular registrars:
- GoDaddy (godaddy.com)
- Namecheap (namecheap.com)
- Google Domains (domains.google.com)
- BigRock (bigrock.com)

### Step 2: Update DNS Records

For Netlify/Vercel, add CNAME:
```
Name: @
Type: CNAME
Value: your-site.netlify.app
```

Or add A records:
```
Type: A
Value: [IP address provided by host]
```

### Step 3: Verify Domain

```bash
# Check DNS propagation
nslookup sonehealthcare.com

# Should show your hosting IP/CNAME
```

### Step 4: Update Links

In index.html, update:
```html
<link rel="canonical" href="https://sonehealthcare.com">
<meta property="og:url" content="https://sonehealthcare.com">
```

---

## SSL Certificate

### Option 1: Free (Let's Encrypt)

**On Traditional Hosting:**
- Usually automatic via cPanel's AutoSSL
- Just enable HTTPS in settings

**On Netlify/Vercel:**
- Automatic, enabled by default
- No action needed

### Option 2: Premium Certificates

- RapidSSL: ~$5/year
- Comodo: ~$10/year
- DigiCert: ~$100/year

### Verify SSL

```bash
# Check certificate
curl -vI https://sonehealthcare.com

# Should show "SSL certificate verify ok"
```

---

## Post-Deployment Checklist

### Security
- [ ] Enable HTTPS (SSL)
- [ ] Set security headers
- [ ] Enable GZIP compression
- [ ] Setup firewall rules
- [ ] Enable backups

### Performance
- [ ] Test load times
- [ ] Enable caching
- [ ] Optimize images
- [ ] Minify files
- [ ] Setup CDN

### SEO
- [ ] Submit sitemap to Google
- [ ] Claim Google Business
- [ ] Setup Google Analytics
- [ ] Setup Search Console
- [ ] Submit to Bing Webmaster

### Testing
- [ ] Test on mobile
- [ ] Test on desktop
- [ ] Test all forms
- [ ] Test all links
- [ ] Browser compatibility

---

## Monitoring & Maintenance

### Uptime Monitoring

Free services:
- UptimeRobot (uptimerobot.com)
- Pingdom (pingdom.com)
- Freshping (freshping.com)

Setup:
1. Create account
2. Add your website URL
3. Get alerts if down

### Performance Monitoring

```bash
# Regular speed tests
1. Google PageSpeed Insights
2. GTmetrix
3. WebPageTest
```

### Log Monitoring

Check server logs weekly:
```bash
# SSH into server
ssh user@your-domain.com

# Check error logs
cat /var/log/apache2/error.log

# Check access logs
cat /var/log/apache2/access.log
```

---

## Troubleshooting

### Site Not Loading

```bash
# Check DNS
nslookup sonehealthcare.com

# Check if files exist
# Check file permissions
# Check server error logs
```

### Slow Loading

```bash
# Enable GZIP
# Compress images
# Enable caching
# Use CDN
# Optimize code
```

### HTTPS Issues

```bash
# Verify certificate
curl -vI https://sonehealthcare.com

# Check certificate expiry
openssl s_client -connect sonehealthcare.com:443
```

---

## Deployment Comparison

| Platform | Cost | Ease | Performance | Recommended |
|----------|------|------|-------------|-------------|
| Netlify | Free | Easy | Excellent | ✓ Yes |
| Vercel | Free | Easy | Excellent | Yes |
| GitHub Pages | Free | Easy | Good | Yes |
| Traditional | $3-10/mo | Medium | Good | For advanced |
| Docker | $5-50/mo | Hard | Excellent | For scaling |

---

## Quick Deploy Command

**For Netlify:**
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod
```

**For Vercel:**
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel --prod
```

---

## Support Resources

- **Netlify Docs:** docs.netlify.com
- **Vercel Docs:** vercel.com/docs
- **GitHub Pages:** pages.github.com
- **Let's Encrypt:** letsencrypt.org

---

**Version:** 1.0
**Last Updated:** January 2024

Good luck with your deployment! 🚀
