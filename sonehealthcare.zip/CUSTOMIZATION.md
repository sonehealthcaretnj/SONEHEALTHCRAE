# 🎨 Customization Guide - S ONE Healthcare Website

Learn how to customize every aspect of your website without touching code.

---

## Table of Contents
1. [Colors & Branding](#colors--branding)
2. [Content Updates](#content-updates)
3. [Sections & Layout](#sections--layout)
4. [Typography](#typography)
5. [Images & Media](#images--media)
6. [Advanced Customization](#advanced-customization)

---

## Colors & Branding

### Primary Colors

Edit `css/styles.css` at the top:

```css
:root {
    --primary: #0d6e4f;        /* Main brand color (green) */
    --primary-light: #1a9b6e;  /* Lighter version */
    --secondary: #f4a261;      /* Accent color (orange) */
    --accent: #e76f51;         /* Additional accent (red) */
    --dark: #1a1a1a;           /* Text color */
    --light: #f8f9fa;          /* Light background */
}
```

### Suggested Color Schemes

**Option 1: Professional Medical (Current)**
```css
--primary: #0d6e4f;      /* Green */
--secondary: #f4a261;    /* Orange */
```

**Option 2: Modern Blue**
```css
--primary: #0066cc;      /* Blue */
--primary-light: #0099ff;
--secondary: #ffb700;    /* Amber */
```

**Option 3: Clinical Red**
```css
--primary: #cc0000;      /* Red */
--primary-light: #ff3333;
--secondary: #0099cc;    /* Blue */
```

**Option 4: Health Green**
```css
--primary: #2e7d32;      /* Dark green */
--primary-light: #4caf50;
--secondary: #ff6f00;    /* Orange */
```

### Apply Colors to Elements

- **Buttons:** Use `--primary`
- **Headings:** Use `--primary`
- **Accents:** Use `--secondary`
- **Text:** Use `--dark`
- **Backgrounds:** Use `--light`

---

## Content Updates

### Update Business Information

Find in `index.html`:

```html
<!-- Phone Numbers -->
<p>98653 24523<br>90038 43599</p>

<!-- Email -->
<p>sonehealthcaretnj@gmail.com</p>

<!-- Address -->
<p>82 W, Ground Floor, Shop No. 4,<br>
Natarajapuram South, 6th Street, MC Road,<br>
Thanjavur – 613007</p>

<!-- Business Hours -->
<div class="stat-card">
    <div class="stat-number">24/7</div>  <!-- Change this -->
    <div class="stat-label">Service Hours</div>
</div>
```

### Update Hero Section

```html
<h1 class="hero-title">Your New Headline</h1>
<p class="hero-subtitle">Your new subtitle here</p>
```

### Update About Section

```html
<p class="highlight">Replace this with your about text</p>
<p>Update this paragraph with more details</p>
```

### Update Statistics

```html
<div class="stat-card">
    <div class="stat-number">50+</div>      <!-- Change number -->
    <div class="stat-label">Doctors</div>  <!-- Change label -->
</div>
```

### Update Services

Each service card:
```html
<div class="service-card">
    <div class="service-icon">🏥</div>        <!-- Change emoji -->
    <h3>Service Name</h3>                     <!-- Change title -->
    <p>Service description here</p>           <!-- Change description -->
    <div class="service-features">
        <span class="feature-tag">Feature 1</span>   <!-- Change -->
        <span class="feature-tag">Feature 2</span>   <!-- Change -->
    </div>
</div>
```

### Update Timeline

```html
<div class="timeline-item" data-year="2002">
    <div class="timeline-marker">
        <div class="marker-icon">🏢</div>    <!-- Change emoji -->
    </div>
    <div class="timeline-content">
        <h3>Event Name</h3>                   <!-- Change title -->
        <p>Event description</p>              <!-- Change description -->
    </div>
</div>
```

---

## Sections & Layout

### Adding a New Section

```html
<!-- Copy this template -->
<section id="new-section" class="new-section">
    <div class="container">
        <div class="section-header">
            <h2>New Section Title</h2>
            <div class="header-underline"></div>
        </div>
        <!-- Your content here -->
    </div>
</section>
```

Add CSS:
```css
.new-section {
    padding: 100px 0;
    background: #ffffff;
}
```

### Hiding Sections

To hide any section, add in CSS:
```css
/* Hide journey section */
.journey {
    display: none;
}
```

### Changing Section Order

Sections can be reordered in HTML by moving the entire `<section>` block.

### Adjusting Padding

```css
/* Increase top padding */
.hero {
    padding: 200px 0 100px;  /* Change first number */
}

/* Increase bottom padding */
.about {
    padding: 150px 0;  /* Increase number */
}
```

---

## Typography

### Change Fonts

Update imports in `<head>`:

```html
<!-- Current fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&family=Playfair+Display:wght@600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">

<!-- Alternative: Roboto + Open Sans -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">

<!-- Alternative: Montserrat + Lato -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
```

Update CSS:
```css
/* Current */
h1, h2, h3 {
    font-family: 'Playfair Display', serif;
}

body {
    font-family: 'Inter', sans-serif;
}

/* Change to Roboto + Open Sans */
h1, h2, h3 {
    font-family: 'Roboto', sans-serif;
}

body {
    font-family: 'Open Sans', sans-serif;
}
```

### Change Font Sizes

```css
h1 {
    font-size: 3.5rem;  /* Change this */
}

h2 {
    font-size: 2.8rem;  /* Change this */
}

h3 {
    font-size: 1.8rem;  /* Change this */
}

p {
    font-size: 1rem;    /* Change this */
}
```

### Change Line Heights

```css
h1, h2, h3 {
    line-height: 1.2;   /* Smaller = tighter */
}

p {
    line-height: 1.8;   /* Larger = more spacing */
}
```

---

## Images & Media

### Add Your Logo

Replace favicon:
```html
<link rel="icon" type="image/x-icon" href="assets/favicon.ico">
```

Add logo to navbar:
```html
<div class="logo-icon">
    <img src="assets/logo.png" alt="S ONE Healthcare" width="40" height="40">
</div>
```

### Add Hero Image

```html
<div class="hero-visual">
    <img src="assets/hero-image.jpg" alt="Healthcare services">
</div>
```

Add CSS:
```css
.hero-visual img {
    width: 100%;
    border-radius: 15px;
    box-shadow: var(--shadow);
}
```

### Add Section Images

```html
<div class="about-image">
    <img src="assets/about-image.jpg" alt="About S ONE Healthcare">
</div>
```

### Image Optimization Tips

```bash
# Compress images (keep < 100KB)
1. Use TinyPNG (tinypng.com)
2. Use ImageOptim (Mac)
3. Use FileOptimizer (Windows)

# Recommended formats:
- JPG: for photos
- PNG: for graphics with transparency
- WebP: for modern browsers (best compression)
```

### Add Background Images

```css
.hero {
    background-image: url('assets/pattern.png');
    background-size: cover;
    background-position: center;
}
```

---

## Advanced Customization

### Change Hover Effects

```css
/* Service card hover */
.service-card:hover {
    transform: translateY(-15px);  /* Change distance */
    box-shadow: var(--shadow-lg);
}
```

### Adjust Animation Speed

```css
@keyframes slideInUp {
    /* Change 0.8s to slower/faster */
    animation: slideInUp 0.8s ease-out;
}
```

Options:
- `0.3s` - Fast
- `0.6s` - Medium
- `1s` - Slow
- `1.5s` - Very Slow

### Add New Animations

```css
@keyframes pulse {
    0%, 100% {
        opacity: 1;
    }
    50% {
        opacity: 0.5;
    }
}

/* Apply to element */
.element {
    animation: pulse 2s ease-in-out infinite;
}
```

### Modify Button Styles

```css
.btn-primary {
    padding: 12px 28px;      /* Change padding */
    border-radius: 50px;     /* Change roundness */
    font-size: 1rem;         /* Change text size */
    text-transform: uppercase; /* Change case */
}

.btn-primary:hover {
    transform: translateY(-3px);  /* Change hover effect */
    box-shadow: var(--shadow-lg);
}
```

### Change Form Styling

```css
.form-group input,
.form-group textarea {
    padding: 12px 15px;           /* Change padding */
    border-radius: 8px;           /* Change roundness */
    border: 1px solid #e0e0e0;   /* Change border */
}

.form-group input:focus {
    border-color: var(--primary); /* Change focus color */
    box-shadow: 0 0 0 3px rgba(13, 110, 79, 0.1);
}
```

### Add Custom CSS Classes

```html
<!-- In HTML -->
<div class="custom-class">Your content</div>

<!-- In CSS -->
<style>
    .custom-class {
        background: linear-gradient(135deg, #primary, #secondary);
        padding: 2rem;
        border-radius: 15px;
        color: white;
    }
</style>
```

### Add Animations to Elements

```html
<!-- In HTML -->
<div class="animated">Content with animation</div>

<!-- In CSS -->
<style>
    .animated {
        animation: slideInUp 0.8s ease-out;
    }
</style>
```

---

## Mobile Customization

### Adjust Mobile Breakpoint

```css
/* Current: Mobile at 768px */
@media (max-width: 768px) {
    /* Mobile styles */
}

/* Change to 960px */
@media (max-width: 960px) {
    /* Tablet styles */
}
```

### Mobile-Specific Styling

```css
@media (max-width: 480px) {
    h1 {
        font-size: 1.8rem;  /* Smaller on mobile */
    }
    
    .container {
        padding: 0 15px;    /* More margin on mobile */
    }
}
```

---

## Meta Tags Customization

### Update Meta Description

```html
<meta name="description" content="Your custom description here (160 chars max)">
```

### Update OpenGraph Tags

```html
<meta property="og:title" content="Your title">
<meta property="og:description" content="Your description">
<meta property="og:image" content="https://yoursite.com/image.jpg">
```

### Add Google Analytics

```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

---

## Common Changes

### Change Primary Color

```css
:root {
    --primary: #0066cc;        /* Change this to your color */
    --primary-light: #0099ff;  /* Update light version too */
}
```

### Change Button Text

In HTML, find and update:
```html
<button class="btn btn-primary">New Text</button>
```

### Add Your Phone Number

Find in HTML:
```html
<p>98653 24523</p>  <!-- Change this -->
```

### Update Email

Find in HTML:
```html
<p>your-email@gmail.com</p>  <!-- Change this -->
```

### Change Service Cards

Each card follows same structure:
```html
<div class="service-card">
    <div class="service-icon">🏥</div>
    <h3>Service Name</h3>
    <p>Description</p>
</div>
```

---

## Testing Changes

After making changes:

1. **Save files**
2. **Refresh browser** (Ctrl+Shift+Delete to clear cache)
3. **Test on mobile** (F12 → Toggle device toolbar)
4. **Check colors** across browser
5. **Test links** and navigation
6. **Verify forms** work correctly

---

## Backup Your Changes

Always keep a backup:

```bash
# Create backup
cp -r s-one-healthcare s-one-healthcare-backup

# Or use Git
git add .
git commit -m "Updated colors and content"
```

---

## Getting Help

- **CSS Issues?** Check CSS-Tricks or MDN
- **HTML Issues?** Check MDN Web Docs
- **Design Ideas?** Check Dribbble or Behance
- **Color Combinations?** Use Coolors.co

---

**Version:** 1.0
**Last Updated:** January 2024

Happy customizing! 🎨
